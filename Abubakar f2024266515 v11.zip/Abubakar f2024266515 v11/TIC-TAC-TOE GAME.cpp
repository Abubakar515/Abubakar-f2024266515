#include <iostream>
using namespace std;

int main() 
{
char board[3][3]={{'1','2','3'},{'4','5','6'},{'7','8','9'}};  
int choice;
char player = 'X'; 
cout<<"ABUBAKAR        F2024266515";
while(true)
{

cout<<"\nTic-Tac-Toe GAME:"<<endl;
for(int i=0;i<3;i++) 
{
for(int j=0;j<3;j++) 
{
cout<<" "<<board[i][j]<<" ";
if(j<2) 
cout << "|";
}
cout<<endl;
if(i<2) 
cout<<"---|---|---"<<endl;
}

cout<<"\nPlayer "<<player<<" , choose a position (1-9): ";
cin>>choice;
int row=(choice-1)/3;
int col =(choice-1)%3;

if(board[row][col]=='X' || board[row][col]=='O') 
{
cout<<"Position already taken! Try again."<<endl;
continue;
}

board[row][col]=player;

for(int i=0;i<3;i++) 
{

if(board[i][0]==board[i][1] && board[i][1]==board[i][2]) 
{
cout<<"Player "<<player<<" wins!"<<endl;
return 0;
}

if(board[0][i]==board[1][i] && board[1][i]==board[2][i]) 
{
cout<<"Player "<<player<<" wins!"<<endl;
return 0;
}
}

if ((board[0][0] == board[1][1] && board[1][1] == board[2][2]) || (board[0][2] == board[1][1] && board[1][1] == board[2][0])) {
cout<<"Player "<<player<<" wins!"<<endl;
return 0;
}

int draw=1;  

for(int i=0;i<3;i++) 
{
for(int j=0;j<3;j++) 
{
if(board[i][j]!='X' && board[i][j]!='O') 
{
draw=0;  
break;
}
}
}
if(draw==1) 
{
cout<<"It's a draw!"<<endl;
return 0;
}


if(player=='X') 
{
player='O';
} 
else 
{
player='X';
}
}
return 0;
}
